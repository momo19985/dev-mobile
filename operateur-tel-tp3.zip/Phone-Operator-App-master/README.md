# Phone-Operator-App

## Requirements :

### Before viewing " Phone Operator App" you need to login 

### Username & Password : slim

## Prerequisites:

### Android Studio 2022

### Gradle version : 7.4.2

### If You Are Using Older Version Try To Downgrade Gradle Version 

### It will work smooth For you , Enjoy ! :D

## Screenshots :

### Login Interface :

![operator app 1](https://user-images.githubusercontent.com/71633887/226518749-8591b827-946b-4b4c-8975-dfd420802f1e.JPG)

### Oreedoo Phone Number :

![oreedoo](https://user-images.githubusercontent.com/71633887/226518796-23d1c3af-8a79-4fab-8a60-046718cc5428.JPG)

### Orange Phone Number :

![orange](https://user-images.githubusercontent.com/71633887/226518839-54938beb-b82b-4e3c-928d-39846b3b4357.JPG)

### Telecom Phone Number :

![telecom](https://user-images.githubusercontent.com/71633887/226518862-04e1bf99-db36-415c-8401-3369bc46ecd9.JPG)
